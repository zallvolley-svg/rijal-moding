package com.rijalmod.optimizer;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.StatFs;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(10, 13, 16);
    private final int PANEL = Color.rgb(21, 27, 31);
    private final int GREEN = Color.rgb(111, 235, 137);
    private final int MUTED = Color.rgb(153, 166, 160);
    private LinearLayout root, gamesContainer;
    private TextView ramValue, storageValue, gameCount;
    private final List<AppEntry> games = new ArrayList<>();

    static class AppEntry {
        String label, packageName;
        android.graphics.drawable.Drawable icon;
        AppEntry(String l, String p, android.graphics.drawable.Drawable i) {
            label=l; packageName=p; icon=i;
        }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildUi();
        refreshStats();
        loadGames();
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    private void pad(View v, int l, int t, int r, int b) { v.setPadding(l,t,r,b); }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root = column();
        root.setBackgroundColor(BG);
        pad(root, 20, 24, 20, 28);
        scroll.addView(root);
        setContentView(scroll);

        LinearLayout header = row();
        TextView brand = text("RIJAL MOD", 24, Color.WHITE, true);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        TextView premium = text("PREMIUM", 11, GREEN, true);
        pad(premium, 12, 7, 12, 7);
        premium.setBackground(shape(Color.rgb(26,57,39), 30));
        header.addView(premium);
        root.addView(header);
        TextView subtitle = text("GAME OPTIMIZER  •  VERSION 1.0", 10, MUTED, true);
        LinearLayout.LayoutParams subLp = lp(-2,-2); subLp.topMargin=5;
        root.addView(subtitle, subLp);

        LinearLayout hero = column();
        hero.setBackground(shape(PANEL, 22)); pad(hero,18,18,18,18);
        LinearLayout.LayoutParams heroLp=lp(-1,-2); heroLp.topMargin=24;
        root.addView(hero, heroLp);
        TextView label=text("DEVICE OVERVIEW",11,GREEN,true);
        hero.addView(label);
        TextView headline=text("Your gaming setup",22,Color.WHITE,true);
        LinearLayout.LayoutParams hLp=lp(-1,-2); hLp.topMargin=7; hero.addView(headline,hLp);
        TextView desc=text("Pantau kondisi perangkat sebelum bermain.",13,MUTED,false);
        LinearLayout.LayoutParams dLp=lp(-1,-2); dLp.topMargin=4; hero.addView(desc,dLp);

        LinearLayout stats=row();
        LinearLayout.LayoutParams statsLp=lp(-1,-2); statsLp.topMargin=20;
        hero.addView(stats,statsLp);
        LinearLayout ram=statCard("RAM TERSEDIA");
        ramValue=(TextView)ram.getTag();
        LinearLayout storage=statCard("PENYIMPANAN");
        storageValue=(TextView)storage.getTag();
        stats.addView(ram,new LinearLayout.LayoutParams(0,-2,1));
        View gap=new View(this); stats.addView(gap,lp(10,1));
        stats.addView(storage,new LinearLayout.LayoutParams(0,-2,1));

        Button boost=button("OPTIMIZE DEVICE");
        LinearLayout.LayoutParams bLp=lp(-1,52); bLp.topMargin=18;
        hero.addView(boost,bLp);
        boost.setOnClickListener(v -> openOptimization());

        LinearLayout section=row();
        LinearLayout.LayoutParams secLp=lp(-1,-2); secLp.topMargin=28;
        root.addView(section,secLp);
        section.addView(text("GAME SPACE",18,Color.WHITE,true),new LinearLayout.LayoutParams(0,-2,1));
        gameCount=text("SCANNING",10,GREEN,true); section.addView(gameCount);
        TextView gameHint=text("Game yang terpasang dan bisa dibuka dari sini.",12,MUTED,false);
        LinearLayout.LayoutParams hintLp=lp(-1,-2); hintLp.topMargin=5; root.addView(gameHint,hintLp);

        gamesContainer=column();
        LinearLayout.LayoutParams listLp=lp(-1,-2); listLp.topMargin=13;
        root.addView(gamesContainer,listLp);

        LinearLayout pixelCard=column();
        pixelCard.setBackground(shape(Color.rgb(15,43,29),18)); pad(pixelCard,16,15,16,15);
        LinearLayout.LayoutParams pixelLp=lp(-1,-2); pixelLp.topMargin=22; root.addView(pixelCard,pixelLp);
        LinearLayout pixelHead=row(); pixelCard.addView(pixelHead);
        pixelHead.addView(text("PIXEL TEXTURE",16,Color.WHITE,true),new LinearLayout.LayoutParams(0,-2,1));
        TextView pixelTag=text("NEW FEATURE",9,GREEN,true); pad(pixelTag,9,6,9,6);
        pixelTag.setBackground(shape(Color.rgb(26,75,48),30)); pixelHead.addView(pixelTag);
        TextView pixelDesc=text("Atur tampilan tekstur ringan dengan pratinjau piksel.",12,MUTED,false);
        LinearLayout.LayoutParams pd=lp(-1,-2); pd.topMargin=6; pixelCard.addView(pixelDesc,pd);
        Button pixelButton=button("BUKA PIXEL LAB");
        LinearLayout.LayoutParams pb=lp(-1,48); pb.topMargin=13; pixelCard.addView(pixelButton,pb);
        pixelButton.setOnClickListener(v -> startActivity(new Intent(this, PixelTextureActivity.class)));

        TextView toolsTitle=text("QUICK TOOLS",18,Color.WHITE,true);
        LinearLayout.LayoutParams tt=lp(-1,-2); tt.topMargin=27; root.addView(toolsTitle,tt);
        LinearLayout tools=row();
        LinearLayout.LayoutParams tlp=lp(-1,-2); tlp.topMargin=12; root.addView(tools,tlp);
        Button settings=smallButton("SYSTEM SETTINGS");
        Button refresh=smallButton("REFRESH");
        tools.addView(settings,new LinearLayout.LayoutParams(0,48,1));
        View g2=new View(this); tools.addView(g2,lp(10,1));
        tools.addView(refresh,new LinearLayout.LayoutParams(0,48,1));
        settings.setOnClickListener(v -> {
            try { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
            catch(Exception e) { Toast.makeText(this,"Pengaturan tidak tersedia",Toast.LENGTH_SHORT).show(); }
        });
        refresh.setOnClickListener(v -> { refreshStats(); loadGames(); Toast.makeText(this,"Data diperbarui",Toast.LENGTH_SHORT).show(); });

        Button pixelLab = button("PIXEL LAB  •  TEXTURE RINGAN");
        LinearLayout.LayoutParams pixelLp = lp(-1, 52); pixelLp.topMargin = 12;
        root.addView(pixelLab, pixelLp);
        pixelLab.setOnClickListener(v -> {
            if (games.isEmpty()) {
                openPixelLab(null, "Profil umum");
                return;
            }
            String[] labels = new String[games.size()];
            for (int i = 0; i < games.size(); i++) labels[i] = games.get(i).label;
            new android.app.AlertDialog.Builder(this)
                .setTitle("Pilih game untuk Pixel Lab")
                .setItems(labels, (dialog, which) -> {
                    AppEntry chosen = games.get(which);
                    openPixelLab(chosen.packageName, chosen.label);
                })
                .setNegativeButton("Batal", null)
                .show();
        });

                LinearLayout ffProfiles = row();
        LinearLayout.LayoutParams ffProfilesLp = lp(-1, 48);
        ffProfilesLp.topMargin = 9;
        root.addView(ffProfiles, ffProfilesLp);
        Button freeFireProfile = smallButton("FREE FIRE");
        Button freeFireMaxProfile = smallButton("FREE FIRE MAX");
        ffProfiles.addView(freeFireProfile, new LinearLayout.LayoutParams(0, -1, 1));
        View ffGap = new View(this); ffProfiles.addView(ffGap, lp(9, 1));
        ffProfiles.addView(freeFireMaxProfile, new LinearLayout.LayoutParams(0, -1, 1));
        freeFireProfile.setOnClickListener(v -> openPixelLab("com.dts.freefireth", "Free Fire"));
        freeFireMaxProfile.setOnClickListener(v -> openPixelLab("com.dts.freefiremax", "Free Fire MAX"));

        TextView note=text("RIJAL MOD tidak mengubah batas perangkat atau menutup paksa aplikasi lain. Optimasi menggunakan fitur sistem Android yang tersedia.",11,MUTED,false);
        LinearLayout.LayoutParams nlp=lp(-1,-2); nlp.topMargin=22; root.addView(note,nlp);
    }

    private LinearLayout statCard(String title) {
        LinearLayout c=column(); c.setBackground(shape(Color.rgb(30,38,42),16)); pad(c,12,12,12,12);
        c.addView(text(title,9,MUTED,true));
        TextView value=text("--",20,Color.WHITE,true);
        LinearLayout.LayoutParams v=lp(-1,-2); v.topMargin=8; c.addView(value,v);
        c.setTag(value); return c;
    }

    private Button button(String label) {
        Button b=new Button(this); b.setText(label); b.setTextSize(13); b.setTextColor(Color.rgb(7,20,12));
        b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setAllCaps(false); b.setBackground(shape(GREEN,16));
        return b;
    }

    private Button smallButton(String label) {
        Button b=new Button(this); b.setText(label); b.setTextSize(11); b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setAllCaps(false); b.setBackground(shape(PANEL,14));
        return b;
    }

    private void refreshStats() {
        try {
            ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            ramValue.setText(String.format(Locale.getDefault(),"%.1f GB",mi.availMem/1073741824.0));
        } catch(Exception e) { ramValue.setText("N/A"); }
        try {
            StatFs fs=new StatFs(new File(getFilesDir().getAbsolutePath()).getAbsolutePath());
            long free=fs.getAvailableBytes();
            storageValue.setText(String.format(Locale.getDefault(),"%.1f GB",free/1073741824.0));
        } catch(Exception e) { storageValue.setText("N/A"); }
    }

    private void openOptimization() {
        refreshStats();
        new android.app.AlertDialog.Builder(this)
            .setTitle("Device check complete")
            .setMessage("Informasi RAM dan penyimpanan sudah diperbarui. Untuk pengelolaan aplikasi dan baterai, gunakan kontrol resmi Android.")
            .setPositiveButton("APP SETTINGS",(d,w)->{
                try { startActivity(new Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS)); }
                catch(Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
            })
            .setNegativeButton("OK",null).show();
    }


    private void openPixelLab(String gamePackage, String gameLabel) {
        String profileKey = (gamePackage == null || gamePackage.isEmpty()) ? "general" : gamePackage;
        String profileTitle = (gameLabel == null || gameLabel.isEmpty()) ? "Profil umum" : gameLabel;
        android.content.SharedPreferences prefs = getSharedPreferences("pixel_lab_" + profileKey, MODE_PRIVATE);
        String[] modes = {"Soft", "Arcade", "Block Max", "Manual"};
        final String[] selectedMode = {prefs.getString("mode", "Arcade")};
        final int[] level = {prefs.getInt("level", 2)};
        final boolean[] edges = {prefs.getBoolean("edges", true)};
        final boolean[] detail = {prefs.getBoolean("detail", true)};
        final boolean[] enabled = {prefs.getBoolean("enabled", true)};

        LinearLayout panel = column();
        panel.setBackgroundColor(BG);
        pad(panel, 18, 12, 18, 8);

        TextView intro = text("Atur profil tekstur agar tampilan game terasa lebih ringan.", 13, MUTED, false);
        panel.addView(intro);

        TexturePreview preview = new TexturePreview();
        LinearLayout.LayoutParams previewLp = lp(-1, 155);
        previewLp.topMargin = 12;
        panel.addView(preview, previewLp);

        final TextView[] levelLabelRef = new TextView[1];
        final SeekBar[] levelBarRef = new SeekBar[1];
        LinearLayout tabs = row();
        LinearLayout.LayoutParams tabsLp = lp(-1, 44); tabsLp.topMargin = 12;
        panel.addView(tabs, tabsLp);
        TextView[] tabViews = new TextView[modes.length];
        for (int i=0;i<modes.length;i++) {
            final String mode = modes[i];
            TextView tab = text(mode, 10, Color.WHITE, true);
            tab.setGravity(Gravity.CENTER);
            tab.setBackground(shape(mode.equals(selectedMode[0]) ? GREEN : PANEL, 10));
            if (mode.equals(selectedMode[0])) tab.setTextColor(Color.rgb(7,20,12));
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, -1, 1);
            tp.setMargins(2,0,2,0); tabs.addView(tab,tp); tabViews[i]=tab;
            tab.setOnClickListener(v -> {
                selectedMode[0] = mode;
                for (int j=0;j<tabViews.length;j++) {
                    boolean active = modes[j].equals(mode);
                    tabViews[j].setBackground(shape(active ? GREEN : PANEL, 10));
                    tabViews[j].setTextColor(active ? Color.rgb(7,20,12) : Color.WHITE);
                }
                if (mode.equals("Soft")) level[0]=1;
                else if (mode.equals("Arcade")) level[0]=2;
                else if (mode.equals("Block Max")) level[0]=3;
                if (levelLabelRef[0] != null) updateLevelLabel(levelLabelRef[0], level[0]);
                if (levelBarRef[0] != null) levelBarRef[0].setProgress(level[0]);
            });
        }

        LinearLayout levelHeader = row();
        LinearLayout.LayoutParams lh = lp(-1,-2); lh.topMargin=16; panel.addView(levelHeader,lh);
        levelHeader.addView(text("Level tekstur",14,Color.WHITE,true),new LinearLayout.LayoutParams(0,-2,1));
        TextView levelLabel = text(levelName(level[0]),12,GREEN,true); levelHeader.addView(levelLabel);
        levelLabelRef[0] = levelLabel;

        SeekBar levelBar = new SeekBar(this);
        levelBarRef[0] = levelBar;
        levelBar.setMax(3); levelBar.setProgress(level[0]); levelBar.setProgressTintList(android.content.res.ColorStateList.valueOf(GREEN));
        levelBar.setThumbTintList(android.content.res.ColorStateList.valueOf(GREEN));
        LinearLayout.LayoutParams sb = lp(-1,-2); sb.topMargin=4; panel.addView(levelBar,sb);
        levelBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar,int progress,boolean fromUser) {
                level[0]=progress; selectedMode[0]="Manual"; updateLevelLabel(levelLabel,progress);
            }
            public void onStartTrackingTouch(SeekBar seekBar) {}
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        Switch edgeSwitch = new Switch(this); edgeSwitch.setText("Tepi kotak"); edgeSwitch.setTextColor(Color.WHITE);
        edgeSwitch.setChecked(edges[0]); edgeSwitch.setButtonTintList(android.content.res.ColorStateList.valueOf(GREEN));
        LinearLayout.LayoutParams es = lp(-1,-2); es.topMargin=10; panel.addView(edgeSwitch,es);
        edgeSwitch.setOnCheckedChangeListener((b,c)->edges[0]=c);

        Switch detailSwitch = new Switch(this); detailSwitch.setText("Lompat detail jauh"); detailSwitch.setTextColor(Color.WHITE);
        detailSwitch.setChecked(detail[0]); detailSwitch.setButtonTintList(android.content.res.ColorStateList.valueOf(GREEN));
        panel.addView(detailSwitch);
        detailSwitch.setOnCheckedChangeListener((b,c)->detail[0]=c);

        Switch enableSwitch = new Switch(this); enableSwitch.setText("Aktifkan profil Pixel Lab"); enableSwitch.setTextColor(GREEN);
        enableSwitch.setChecked(enabled[0]); panel.addView(enableSwitch);
        enableSwitch.setOnCheckedChangeListener((b,c)->enabled[0]=c);

        TextView info=text("Catatan: profil ini menyimpan preferensi RIJAL MOD. Android tidak mengizinkan aplikasi biasa mengubah tekstur internal game lain secara langsung. Terapkan pengaturan grafis yang sesuai dari dalam game jika tersedia.",10,MUTED,false);
        LinearLayout.LayoutParams infoLp=lp(-1,-2); infoLp.topMargin=8; panel.addView(info,infoLp);

        android.app.AlertDialog dialog = new android.app.AlertDialog.Builder(this)
            .setTitle("PIXEL LAB • " + profileTitle)
            .setView(panel)
            .setNegativeButton("KEMBALIKAN NORMAL",(d,w)->{
                prefs.edit().putString("mode","Soft").putInt("level",0).putBoolean("edges",false)
                    .putBoolean("detail",false).putBoolean("enabled",false).apply();
                Toast.makeText(this,"Profil normal disimpan",Toast.LENGTH_SHORT).show();
            })
            .setPositiveButton("TERAPKAN",(d,w)->{
                prefs.edit().putString("mode",selectedMode[0]).putInt("level",level[0])
                    .putBoolean("edges",edges[0]).putBoolean("detail",detail[0])
                    .putBoolean("enabled",enabled[0]).apply();
                Toast.makeText(this,"Profil Pixel Lab disimpan",Toast.LENGTH_SHORT).show();
            }).create();
        dialog.setOnShowListener(v -> {
            dialog.getButton(-1).setTextColor(Color.rgb(7,20,12));
            dialog.getButton(-2).setTextColor(GREEN);
            dialog.getWindow().setBackgroundDrawable(shape(PANEL,20));
        });
        dialog.show();
        dialog.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels*0.94), -2);
    }

    private String levelName(int level) {
        switch(level) {
            case 0: return "Normal";
            case 1: return "Lembut";
            case 2: return "8-Bit";
            default: return "Blok";
        }
    }

    private void updateLevelLabel(TextView view,int level) {
        view.setText(levelName(level));
    }

    private class TexturePreview extends View {
        private final android.graphics.Paint paint = new android.graphics.Paint();
        TexturePreview() { super(MainActivity.this); setLayerType(View.LAYER_TYPE_SOFTWARE,null); }
        @Override protected void onDraw(android.graphics.Canvas canvas) {
            super.onDraw(canvas);
            int w=getWidth(), h=getHeight();
            paint.setColor(Color.rgb(99,132,79)); canvas.drawColor(Color.rgb(105,133,84));
            int brickH=Math.max(12,h/9), brickW=Math.max(25,w/6);
            for(int y=0;y<h*0.55;y+=brickH) {
                int offset=((y/brickH)%2)*(brickW/2);
                for(int x=-brickW;x<w+brickW;x+=brickW) {
                    paint.setColor(((x/brickW+y/brickH)%3==0)?Color.rgb(133,99,87):Color.rgb(164,126,111));
                    canvas.drawRect(x+offset+2,y+2,x+offset+brickW-2,y+brickH-2,paint);
                }
            }
            for(int y=(int)(h*.55);y<h;y+=7) for(int x=0;x<w;x+=7) {
                int seed=(x*17+y*31)%5;
                paint.setColor(seed<2?Color.rgb(91,126,64):(seed<4?Color.rgb(111,145,69):Color.rgb(128,99,72)));
                canvas.drawRect(x,y,x+6,y+6,paint);
            }
            paint.setColor(Color.WHITE); paint.setStrokeWidth(2);
            canvas.drawLine(w/2f,0,w/2f,h,paint);
            paint.setColor(GREEN); canvas.drawCircle(w/2f,h/2f,13,paint);
            paint.setColor(Color.rgb(7,20,12)); paint.setTextSize(11); paint.setTypeface(Typeface.DEFAULT_BOLD);
            canvas.drawText("<>",w/2f-7,h/2f+4,paint);
            paint.setColor(Color.WHITE); paint.setTextSize(10);
            canvas.drawText("ASLI",10,16,paint); canvas.drawText("HASIL",w-42,16,paint);
        }
    }

    private void loadGames() {
        games.clear();
        PackageManager pm=getPackageManager();
        Intent query=new Intent(Intent.ACTION_MAIN,null);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<android.content.pm.ResolveInfo> apps=pm.queryIntentActivities(query,0);
        for(android.content.pm.ResolveInfo ri:apps) {
            String pkg=ri.activityInfo.packageName;
            if(pkg.equals(getPackageName())) continue;
            try {
                ApplicationInfo ai=pm.getApplicationInfo(pkg,0);
                games.add(new AppEntry(pm.getApplicationLabel(ai).toString(),pkg,pm.getApplicationIcon(ai)));
            } catch(Exception ignored) {}
        }
        Collections.sort(games, Comparator.comparing(a->a.label.toLowerCase(Locale.ROOT)));
        gamesContainer.removeAllViews();
        gameCount.setText(games.size()+" APPS");
        if(games.isEmpty()) {
            TextView empty=text("Belum ada aplikasi yang dapat ditampilkan.",13,MUTED,false);
            empty.setBackground(shape(PANEL,16)); pad(empty,16,18,16,18); gamesContainer.addView(empty);
            return;
        }
        int shown=0;
        for(AppEntry app:games) {
            if(shown++>=30) break;
            LinearLayout item=row(); item.setBackground(shape(PANEL,15)); pad(item,13,10,13,10);
            LinearLayout.LayoutParams ilp=lp(-1,-2); ilp.bottomMargin=8; gamesContainer.addView(item,ilp);
            ImageView icon=new ImageView(this); icon.setImageDrawable(app.icon);
            item.addView(icon,lp(38,38));
            LinearLayout names=column(); LinearLayout.LayoutParams nameLp=new LinearLayout.LayoutParams(0,-2,1);
            nameLp.leftMargin=12; item.addView(names,nameLp);
            names.addView(text(app.label,14,Color.WHITE,true));
            TextView pkg=text(app.packageName,9,MUTED,false); names.addView(pkg);
            TextView texture=text("PIXEL",10,GREEN,true); pad(texture,8,8,8,8);
            item.addView(texture);
            texture.setOnClickListener(v -> openPixelLab(app.packageName, app.label));
            TextView launch=text("OPEN",10,GREEN,true); pad(launch,8,8,8,8); item.addView(launch);
            launch.setOnClickListener(v -> {
                Intent launchIntent=pm.getLaunchIntentForPackage(app.packageName);
                if(launchIntent!=null) startActivity(launchIntent);
                else Toast.makeText(this,"Aplikasi tidak dapat dibuka",Toast.LENGTH_SHORT).show();
            });
            item.setOnClickListener(v -> {
                Intent launchIntent=pm.getLaunchIntentForPackage(app.packageName);
                if(launchIntent!=null) startActivity(launchIntent);
                else Toast.makeText(this,"Aplikasi tidak dapat dibuka",Toast.LENGTH_SHORT).show();
            });
        }
        if(games.size()>30) {
            TextView more=text("Menampilkan 30 dari "+games.size()+" aplikasi.",10,MUTED,false);
            gamesContainer.addView(more);
        }
    }
}
