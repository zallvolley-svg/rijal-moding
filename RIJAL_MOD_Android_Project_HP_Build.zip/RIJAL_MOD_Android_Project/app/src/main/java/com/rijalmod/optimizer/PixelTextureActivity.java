package com.rijalmod.optimizer;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class PixelTextureActivity extends Activity {
    private final int BG=Color.rgb(7,25,17), PANEL=Color.rgb(9,22,16), GREEN=Color.rgb(49,245,139), MUTED=Color.rgb(145,174,157), WHITE=Color.rgb(230,244,235);
    private SharedPreferences prefs;
    private Preview preview;
    private TextView levelText;
    private SeekBar levelSeek;
    private Switch edgeSwitch, detailSwitch, freeFireSwitch;
    private String mode="Arcade";
    private int level=2;

    private GradientDrawable shape(int color,int radius) { GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d; }
    private TextView label(String s,int size,int color,boolean bold) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL); return t; }
    private LinearLayout col() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private void pad(View v,int a,int b,int c,int d) { v.setPadding(a,b,c,d); }
    private LinearLayout.LayoutParams lp(int w,int h) { return new LinearLayout.LayoutParams(w,h); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(Color.BLACK);
        prefs=getSharedPreferences("pixel_texture",MODE_PRIVATE);
        mode=prefs.getString("mode","Arcade"); level=prefs.getInt("level",2);
        build();
    }

    private void build() {
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout page=col(); page.setBackgroundColor(BG); pad(page,18,18,18,28); scroll.addView(page); setContentView(scroll);
        LinearLayout top=row(); page.addView(top);
        TextView back=label("‹",32,GREEN,true); back.setGravity(Gravity.CENTER); top.addView(back,lp(42,44)); back.setOnClickListener(v->finish());
        LinearLayout title=col(); LinearLayout.LayoutParams titleLp=new LinearLayout.LayoutParams(0,-2,1); titleLp.leftMargin=8; top.addView(title,titleLp);
        title.addView(label("RIJAL MOD  ·  PIXEL LAB",10,GREEN,true)); title.addView(label("Tekstur Ringan",21,WHITE,true));

        preview=new Preview(); LinearLayout.LayoutParams prevLp=lp(-1,245); prevLp.topMargin=16; page.addView(preview,prevLp);
        LinearLayout compare=row(); LinearLayout.LayoutParams cLp=lp(-1,-2); cLp.topMargin=7; page.addView(compare,cLp);
        TextView original=label("ASLI",10,WHITE,true); original.setBackground(shape(0xAA111A15,30)); pad(original,12,5,12,5); compare.addView(original);
        View spacer=new View(this); compare.addView(spacer,new LinearLayout.LayoutParams(0,1,1));
        TextView result=label("HASIL",10,WHITE,true); result.setBackground(shape(0xAA111A15,30)); pad(result,12,5,12,5); compare.addView(result);

        LinearLayout modes=row(); modes.setBackground(shape(PANEL,14)); pad(modes,4,4,4,4); LinearLayout.LayoutParams mlp=lp(-1,48); mlp.topMargin=20; page.addView(modes,mlp);
        String[] names={"Soft","Arcade","Block Max","Manual"};
        for(String n:names) { TextView tab=label(n,11,n.equals(mode)?Color.rgb(4,31,17):WHITE,true); tab.setGravity(Gravity.CENTER); tab.setBackground(n.equals(mode)?shape(GREEN,10):shape(Color.TRANSPARENT,10)); modes.addView(tab,new LinearLayout.LayoutParams(0,-1,1)); tab.setOnClickListener(v->{ mode=n; if(!n.equals("Manual")) level=n.equals("Soft")?0:n.equals("Arcade")?2:4; update(); updateModeTabs(modes,names); }); }

        LinearLayout levelRow=row(); LinearLayout.LayoutParams lr=lp(-1,-2); lr.topMargin=18; page.addView(levelRow,lr);
        levelRow.addView(label("Level Piksel",14,WHITE,true),new LinearLayout.LayoutParams(0,-2,1));
        levelText=label(levelName(),12,GREEN,true); levelRow.addView(levelText);
        levelSeek=new SeekBar(this); levelSeek.setMax(4); levelSeek.setProgress(level); levelSeek.setProgressTintList(android.content.res.ColorStateList.valueOf(GREEN)); levelSeek.setThumbTintList(android.content.res.ColorStateList.valueOf(GREEN));
        LinearLayout.LayoutParams slp=lp(-1,35); slp.topMargin=3; page.addView(levelSeek,slp);
        LinearLayout ticks=row(); String[] tick={"Normal","Lembut","8-Bit","Blok","Mozaik"};
        for(String t:tick) { TextView tv=label(t,9,MUTED,false); tv.setGravity(Gravity.CENTER); ticks.addView(tv,new LinearLayout.LayoutParams(0,-2,1)); } page.addView(ticks);
        levelSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){ public void onProgressChanged(SeekBar s,int p,boolean u){level=p;mode="Manual";updateModeTabs(modes,names);levelText.setText(levelName());preview.invalidate();} public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){} });

        edgeSwitch=makeSwitch(page,"Tepi Kotak","Tepi gambar jadi kotak-kotak. Matikan untuk tampilan lebih halus.",prefs.getBoolean("edge",true));
        detailSwitch=makeSwitch(page,"Lompat Detail","Kurangi detail kecil pada pratinjau agar pola terlihat lebih sederhana.",prefs.getBoolean("detail",true));
        freeFireSwitch=makeSwitch(page,"Free Fire","Simpan profil Pixel Lab untuk Free Fire.",prefs.getBoolean("freefire",true));
        TextView hint=label("• Pengaturan ini menyimpan profil visual di RIJAL MOD.\n• Perubahan tekstur game hanya terjadi jika game mendukung konfigurasi eksternal.",10,MUTED,false); LinearLayout.LayoutParams hlp=lp(-1,-2); hlp.topMargin=13; page.addView(hint,hlp);

        LinearLayout actions=row(); LinearLayout.LayoutParams alp=lp(-1,50); alp.topMargin=18; page.addView(actions,alp);
        Button reset=actionButton("↺  Kembalikan Normal",false); actions.addView(reset,new LinearLayout.LayoutParams(0,-1,1));
        View gap=new View(this); actions.addView(gap,lp(8,1));
        Button apply=actionButton("Terapkan",true); actions.addView(apply,new LinearLayout.LayoutParams(0,-1,2));
        reset.setOnClickListener(v->{mode="Soft";level=0;edgeSwitch.setChecked(false);detailSwitch.setChecked(false);update();});
        apply.setOnClickListener(v->{prefs.edit().putString("mode",mode).putInt("level",level).putBoolean("edge",edgeSwitch.isChecked()).putBoolean("detail",detailSwitch.isChecked()).putBoolean("freefire",freeFireSwitch.isChecked()).apply(); Toast.makeText(this,"Profil Pixel Lab tersimpan",Toast.LENGTH_SHORT).show();});
    }

    private Switch makeSwitch(LinearLayout parent,String title,String desc,boolean checked) {
        LinearLayout card=row(); card.setBackground(shape(PANEL,14)); pad(card,13,11,13,11); LinearLayout.LayoutParams cp=lp(-1,-2); cp.topMargin=9; parent.addView(card,cp);
        LinearLayout words=col(); card.addView(words,new LinearLayout.LayoutParams(0,-2,1)); words.addView(label(title,13,WHITE,true)); TextView sub=label(desc,9,MUTED,false); LinearLayout.LayoutParams sp=lp(-1,-2); sp.topMargin=3; words.addView(sub,sp);
        Switch sw=new Switch(this); sw.setChecked(checked); sw.setButtonTintList(android.content.res.ColorStateList.valueOf(GREEN)); card.addView(sw); sw.setOnCheckedChangeListener((b,c)->preview.invalidate()); return sw;
    }
    private Button actionButton(String s,boolean primary) { Button b=new Button(this); b.setText(s); b.setTextSize(11); b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setTextColor(primary?Color.rgb(4,31,17):WHITE); b.setBackground(shape(primary?GREEN:0xFF10291D,12)); return b; }
    private String levelName(){return new String[]{"Normal","Lembut","8-Bit","Blok","Mozaik"}[Math.max(0,Math.min(4,level))];}
    private void update(){ levelSeek.setProgress(level); levelText.setText(levelName()); preview.invalidate(); }
    private void updateModeTabs(LinearLayout modes,String[] names){ for(int i=0;i<modes.getChildCount();i++){TextView t=(TextView)modes.getChildAt(i); boolean selected=names[i].equals(mode); t.setTextColor(selected?Color.rgb(4,31,17):WHITE); t.setBackground(selected?shape(GREEN,10):shape(Color.TRANSPARENT,10));} }

    private class Preview extends View {
        Paint p=new Paint( Paint.ANTI_ALIAS_FLAG );
        Preview(){super(PixelTextureActivity.this);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onDraw(Canvas c){ super.onDraw(c); float w=getWidth(),h=getHeight(); p.setColor(0xFF8B7869); c.drawRoundRect(0,0,w,h,18,18,p);
            int cell= new int[]{34,26,18,12,7}[level];
            for(int y=0;y<h;y+=cell) for(int x=0;x<w;x+=cell){ int v=((x/cell*7+y/cell*11)%9); p.setColor(v<3?0xFF738D4A:v<6?0xFF9D7768:0xFFB18E7E); c.drawRect(x,y,x+cell-1,y+cell-1,p); }
            p.setColor(0xFF5A7B43); c.drawRect(0,h*.57f,w,h,p);
            for(int y=(int)(h*.57f);y<h;y+=Math.max(3,cell/2)) for(int x=0;x<w;x+=Math.max(3,cell/2)){int v=((x+y*3)/Math.max(3,cell/2))%3;p.setColor(v==0?0xFF638B3D:v==1?0xFF92745B:0xFF7C9650);c.drawRect(x,y,x+Math.max(3,cell/2),y+Math.max(3,cell/2),p);}
            if(edgeSwitch!=null&&edgeSwitch.isChecked()){p.setColor(0x55FFFFFF);p.setStrokeWidth(1);for(int x=0;x<w;x+=cell)c.drawLine(x,0,x,h,p);for(int y=0;y<h;y+=cell)c.drawLine(0,y,w,y,p);}
            if(detailSwitch!=null&&detailSwitch.isChecked()){p.setColor(0x44FFFFFF);c.drawRect(w*.5f-1,0,w*.5f+1,h,p);}
            p.setColor(0xAA07130D);c.drawRoundRect(10,10,72,34,12,12,p);p.setColor(WHITE);p.setTextSize(10);p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText("ASLI",19,26,p);
            c.drawText("HASIL",w-56,26,p);
            p.setColor(GREEN);c.drawCircle(w*.5f,h*.5f,17,p);p.setColor(0xFF062213);p.setTextSize(13);c.drawText("↔",w*.5f-7,h*.5f+5,p);
        }
    }
}
