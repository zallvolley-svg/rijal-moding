# RIJAL MOD — Android project

Aplikasi Android native sederhana dengan identitas sendiri, dashboard gelap/hijau, informasi RAM tersedia dan ruang penyimpanan, daftar aplikasi launcher (Game Space), pembuka game, dan pintasan ke pengaturan sistem.

## Batasan fungsi yang disengaja
- Tombol Optimize memperbarui statistik perangkat dan membuka pengaturan aplikasi Android. Android modern membatasi aplikasi pihak ketiga untuk membersihkan RAM/cache aplikasi lain atau memaksa perangkat berjalan pada FPS tertentu.
- Game Space menampilkan aplikasi yang memiliki launcher activity. Tidak semua aplikasi yang tampil adalah game.
- Tidak ada sistem token, login, pembayaran, atau langganan.
- Tidak menggunakan kode, merek dagang, atau aset proprietary dari Zayon Optimize.

## Build APK
Persyaratan:
- Android Studio terbaru
- Android SDK Platform 35
- JDK 17 atau lebih baru
- Gradle yang kompatibel dengan Android Gradle Plugin 8.7.3

Langkah:
1. Ekstrak ZIP.
2. Buka folder `RIJAL_MOD_Android_Project` di Android Studio.
3. Tunggu Gradle Sync selesai.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug akan tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

Package: `com.rijalmod.optimizer`
Min Android: Android 6.0 (API 23)
Target SDK: 35

## Fitur Pixel Lab (v1.1)
- Mode Soft, Arcade, Block Max, dan Manual.
- Slider level piksel 5 tingkat, efek tepi kotak, pengaturan detail, profil Free Fire.
- Pratinjau visual ASLI/HASIL menggunakan pola tekstur demonstrasi.
- Preferensi disimpan lokal pada perangkat. Ini tidak mengubah file tekstur internal game; integrasi game memerlukan dukungan resmi dari game atau mod yang memang dapat dikonfigurasi.

## Pixel Lab — Texture Ringan (fitur baru)
- Preset Soft, Arcade, Block Max, dan Manual.
- Slider level tekstur: Normal, Lembut, 8-Bit, dan Blok.
- Toggle tepi kotak, lompat detail jauh, dan aktif/nonaktif profil.
- Preview perbandingan tekstur bergaya Pixel Lab.
- Profil disimpan lokal menggunakan SharedPreferences.
- Penting: Android tidak memberi aplikasi biasa hak untuk mengubah aset/tekstur internal game lain. Pixel Lab menyimpan profil dan memberi preview; pengaturan grafis aktual tetap perlu diterapkan melalui opsi resmi di dalam game jika tersedia.

## Pixel Lab — profil per game (pembaruan)
- Setiap aplikasi di Game Space memiliki pintasan **PIXEL**.
- Pengaturan Soft / Arcade / Block Max / Manual, level tekstur, tepi kotak, detail jauh, dan status aktif disimpan terpisah berdasarkan package name aplikasi.
- Tombol Pixel Lab di bagian Quick Tools juga dapat memilih game untuk mengedit profilnya.
- Preferensi bertahan setelah aplikasi ditutup karena disimpan lokal di SharedPreferences.
- Pengaturan ini adalah profil/preferensi RIJAL MOD dan preview visual. Android tidak memberi aplikasi biasa izin untuk mengubah tekstur/aset internal aplikasi atau game lain. Penerapan perubahan grafis aktual harus melalui pengaturan resmi game atau izin/format mod yang didukung pengembang game.

## Profil target Free Fire dan Free Fire MAX
- Quick access khusus untuk profil **Free Fire** (`com.dts.freefireth`) dan **Free Fire MAX** (`com.dts.freefiremax`).
- Kedua game memiliki penyimpanan profil Pixel Lab yang terpisah.
- Profil dapat diatur walaupun game belum terpasang; tombol ini hanya mengelola preset lokal RIJAL MOD.
- Nama/package ID dapat berbeda pada distribusi regional tertentu. Jika game pengguna memakai package ID berbeda, pilih game dari daftar Game Space dan tekan PIXEL pada baris game tersebut.
- Tidak ada injeksi ke proses game, pengubahan OBB/data game, atau bypass anti-cheat. Android tidak memberikan izin umum bagi aplikasi pihak ketiga untuk mengganti tekstur internal game lain. Gunakan pengaturan grafis resmi dalam game untuk menerapkan perubahan yang didukung.


## Build dan pemasangan APK
Build belum dapat dijalankan di lingkungan penyusunan ini karena Android SDK, Gradle, dan Android build tools tidak tersedia. Ini bukan APK yang sudah teruji.

Di komputer dengan Android Studio:
1. Pasang Android Studio dan Android SDK Platform 35.
2. Buka folder proyek `RIJAL_MOD_Android_Project`.
3. Pastikan Gradle JDK menggunakan JDK 17.
4. Tunggu Gradle Sync selesai.
5. Jalankan **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. File debug APK: `app/build/outputs/apk/debug/app-debug.apk`.

Untuk memasang ke HP, pindahkan APK debug tersebut ke Android dan izinkan pemasangan dari sumber yang Anda pilih. Untuk distribusi publik, buat signed release APK melalui **Build > Generate Signed Bundle / APK**.


## Build APK hanya menggunakan HP Android (GitHub Actions)
Proyek menyertakan workflow cloud `.github/workflows/build-apk.yml`. Kompilasi berlangsung di server GitHub, bukan di HP.

1. Unduh ZIP proyek ini ke HP.
2. Buat akun atau masuk ke GitHub melalui browser.
3. Buat repository baru, misalnya `rijal-mod`, dan pilih **Public** atau **Private**.
4. Di repository, pilih **Add file > Upload files**, lalu unggah isi ZIP yang sudah diekstrak (pastikan folder `.github/workflows` ikut terunggah). Jika antarmuka HP tidak menampilkan folder tersembunyi, aktifkan tampilan file tersembunyi di aplikasi pengelola file atau unggah lewat GitHub web dengan browser mode desktop.
5. Buka tab **Actions**, pilih **Build RIJAL MOD APK**, lalu tekan **Run workflow**.
6. Tunggu sampai workflow selesai dengan status hijau.
7. Buka hasil run dan unduh artifact `rijal-mod-debug-apk`. Ekstrak artifact ZIP untuk mendapatkan `app-debug.apk`.
8. Buka APK di HP dan izinkan instalasi dari sumber tersebut jika Android meminta.

Catatan: GitHub Actions memerlukan akun GitHub dan koneksi internet. APK yang dihasilkan adalah debug APK untuk pengujian, bukan release APK bertanda tangan untuk distribusi luas.
